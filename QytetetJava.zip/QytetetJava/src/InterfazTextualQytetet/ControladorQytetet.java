/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfazTextualQytetet;

import java.util.ArrayList;
import java.util.Scanner;
import modeloqytetet.*;

/**
 *
 * @author jjavier98
 */
public class ControladorQytetet {

    private static Qytetet juego;
    private static Jugador jugador;
    private static Casilla casilla;
    private static VistaTextualQytetet vista;

    /*public ControladorQytetet(Qytetet juego, Jugador jugador, Casilla casilla) {
        this.juego = juego;
        this.jugador = jugador;
        this.casilla = casilla;
    }*/
    public static void inicializacionJuego()
    {
        Scanner scan = new Scanner(System.in);
        String n;
        
        juego = Qytetet.getInstance();
        vista = new VistaTextualQytetet();
        juego.inicializarJuego(vista.obtenerNombreJugadores());
        
        jugador = juego.getJugadorActual();
        casilla = jugador.getCasillaActual();
        
        System.out.println(juego);
               
        System.out.println("\n\n\nPara empezar a jugar pulsa INTRO: ");
        n = scan.nextLine();
    }
    
    public static void desarrolloDelJuego(){
        
        boolean libre, tienePropietario;
        boolean fin = false;
        int metodo_salir;
        MetodoSalirCarcel m;
        
        while(!fin)
        {

            System.out.println("Es el turno de:\n" + jugador);

            if(jugador.isEncarcelado())
            {
                metodo_salir = vista.menuSalirCarcel();

                if(metodo_salir == 1)
                {
                    m = MetodoSalirCarcel.PAGANDOLIBERTAD;
                }
                else
                {
                    m = MetodoSalirCarcel.TIRANDODADO;
                }

                libre = juego.intentarSalirCarcel(m);

                if(libre)
                    System.out.println("Has quedado libre de la carcel.");
            }

            if(!jugador.isEncarcelado())
            {
                tienePropietario = juego.jugar();
                casilla = jugador.getCasillaActual();

                if(jugador.getSaldo() > 0 && !jugador.isEncarcelado()) // NO ESTÁ EN BANCARROTA NI ESTÁ ENCARCELADO
                {

                    if(casilla.getTipo() == TipoCasilla.CALLE)
                    {                        
                        if(!tienePropietario)
                        {
                            System.out.println("Estás en: " + casilla);
                            
                            boolean comprar = vista.elegirQuieroComprar();
                            if(comprar)
                            {
                                if(jugador.comprarTitulo())
                                {
                                    System.out.println("Has comprado la casilla.\n");
                                }
                            }

                        }
                    }
                    else if(casilla.getTipo() == TipoCasilla.SORPRESA)
                    {
                        tienePropietario = juego.aplicarSorpresa();
                        casilla = jugador.getCasillaActual();

                        if(!jugador.isEncarcelado() && jugador.getSaldo() > 0 && casilla.getTipo() == TipoCasilla.CALLE && !tienePropietario)
                        {
                            System.out.println("Estás en: " + casilla);
                            if(vista.elegirQuieroComprar())
                            {
                                if(jugador.comprarTitulo())
                                {
                                    System.out.println("Has comprado la casilla.\n");
                                }
                            }
                        }
                    }
                    
                    if(!jugador.isEncarcelado() && jugador.getSaldo() > 0 && jugador.tengoPropiedades())
                    {
                        /*ArrayList<String> nombresPropiedades = new ArrayList<>();
                        for (TituloPropiedad prop : jugador.getPropiedades()) {
                            nombresPropiedades.add(prop.getNombre());
                        }*/
                        int opcion = vista.menuGestionInmobiliaria();

                        while(opcion != 0)
                        {
                            ArrayList<Casilla> cas = new ArrayList<Casilla>();

                            for (TituloPropiedad titulo : jugador.getPropiedades()) {
                                cas.add(titulo.getCasilla());
                            }
                            Casilla casilla_elegida;
                            casilla_elegida = elegirPropiedad(cas);

                            switch (opcion)
                            {
                                case 1: juego.edificarCasa(casilla_elegida);
                                        break;
                                case 2: juego.edificarHotel(casilla_elegida);
                                        break;
                                case 3: juego.venderPropiedad(casilla_elegida);
                                        break;
                                case 4: juego.hipotecarPropiedad(casilla_elegida);
                                        break;
                                case 5: juego.cancelarHipoteca(casilla_elegida);
                                        break;
                            }
                            
                            opcion = vista.menuGestionInmobiliaria();
                        }
                    }
                }
            }

            System.out.println("El estado final del jugador es:\n"+jugador);

            fin = jugador.getSaldo() <= 0;

            if(!fin)
            {
                juego.siguienteJugador();
                jugador = juego.getJugadorActual();
                casilla = jugador.getCasillaActual();
                fin = jugador.getSaldo() <= 0;
            }

            if(fin)
            {
                System.out.println("ranking" + juego.obtenerRanking());
            }
        }
    }
    
    //metodo que muestra en pantalla el string que recibe como argumento
    public void mostrar(String texto){
         
        System.out.println(texto);
    }
    
    public static Casilla elegirPropiedad(ArrayList<Casilla> propiedades){ 
    //    este metodo toma una lista de propiedades y genera una lista de strings, con el numero y nombre de las propiedades
    //   luego llama a la vista para que el usuario pueda elegir.
    
        int seleccion;
        ArrayList<String> listaPropiedades= new ArrayList<>();
        
        for ( Casilla casilla: propiedades) {
            vista.mostrar("\tCasilla\tTitulo");
            listaPropiedades.add( "\t"+casilla.getNumeroCasilla()+"\t"+casilla.getTitulo().getNombre()); /*getNumeroCasilla y getNombre no eran publicos*/
        }
        
        for (String lista : listaPropiedades) {
            System.out.println(lista);
        }
        
        seleccion = vista.menuElegirPropiedad(listaPropiedades);
        
    return propiedades.get(seleccion);
    }
    
    public static void main(String[] args) {
        inicializacionJuego();
        desarrolloDelJuego();
    }
    
}
